# Import the python libraries
from pymongo import MongoClient
from pprint import pprint

print ('Connect to MongoClient ...')
# Choose the appropriate client
client = MongoClient()
print ('Client ...', client)

# Connect to the test db 
db=client.test

# Use the employee collection
employee = db.employee
employee_details = {
    'Name': 'Raj Kumar',
    'Address': 'Sears Streer, NZ',
    'Age': '42'
}

# Use the insert method
print ('Insert record ...')
print ('employee_details: ', employee_details)
result = employee.insert_one(employee_details)
print ('result: ', result)
# Query for the inserted document.
print ('Find record ...')
Queryresult = employee.find_one({'Age': '42'})
pprint(Queryresult)