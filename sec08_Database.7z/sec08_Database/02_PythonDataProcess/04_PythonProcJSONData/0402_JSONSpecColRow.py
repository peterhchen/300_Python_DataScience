import pandas as pd
data = pd.read_json('path/input.json')

# Use the multi-axes indexing funtion
print (data)
print ()
print (data.loc[:,['Salary']])
print ()
print (data.loc[[1,3,5],['Salary']])
print ()
print (data.loc[[1,3,5],['Salary','Name']])