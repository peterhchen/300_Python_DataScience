#import urllib2
import urllib.request
from bs4 import BeautifulSoup

# Fetch the html file
# response = urllib2.urlopen('http://tutorialspoint.com/python/python_overview.htm')
response = urllib.request.urlopen('http://tutorialspoint.com/python/python_overview.htm')
html_doc = response.read()

# Parse the html file
soup = BeautifulSoup(html_doc, 'html.parser')

# Format the parsed html file
strhtm = soup.prettify()

# Print the first few characters
print (strhtm[:225])