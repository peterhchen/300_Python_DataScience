#import urllib2
import urllib.request
from bs4 import BeautifulSoup

#response = urllib2.urlopen('http://tutorialspoint.com/python/python_overview.htm')
response = urllib.request.urlopen('http://tutorialspoint.com/python/python_overview.htm')
html_doc = response.read()
soup = BeautifulSoup(html_doc, 'html.parser')

for x in soup.find_all('b'): print(x.string)