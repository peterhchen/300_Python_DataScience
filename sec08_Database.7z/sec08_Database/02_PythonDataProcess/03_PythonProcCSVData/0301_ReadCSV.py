import pandas as pd
data = pd.read_csv('path/input.csv')
print (data)