import datetime

date_today  = datetime.date.today() 

print ('Today is: ', date_today)
# Create a delta of Four Days 
no_of_days = datetime.timedelta(days=4) 
print ('Number of Days:', no_of_days)

# Use Delta for Past Date
before_four_days = date_today - no_of_days 
print ('Before Four Days:', before_four_days) 

after_four_days =  date_today + no_of_days

date1 = datetime.date(2018,4,4)

print ('date1:',date1)

if date1 == before_four_days :
    print ('Same Dates')
if date_today > date1:
    print ('Past Date')
if date1 < after_four_days:
    print ('Future Date')