import pandas as pd
data = pd.read_excel('path/input.csv')
print (data)