'''
Pyhton calulations are hardware-limited.
The exact error depends on the version of Python.
'''
print ('[2**x for x in range (8)]:')
print ([2**x for x in range (8)])
print ()
print ('[2**x for x in range (64)]:')
print ([2**x for x in range(64)])